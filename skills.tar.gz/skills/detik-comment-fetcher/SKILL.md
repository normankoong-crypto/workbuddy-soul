---
name: detik-comment-fetcher
description: Fetch reader comments from detik.com / CNN Indonesia / CNBC Indonesia / Haibunda / Insertlive and other detik-network articles. The comment section is NOT in the page HTML — it loads via a Detik GraphQL backend. Use this when the user wants to read/parse/analyze the comments on any Detik-network article URL.
agent_created: true
---

# Detik Comment Fetcher

Detik-network sites (detik.com, cnnindonesia.com, cnbcindonesia.com, haibunda.com, insertlive.com, etc.) render comments through an **external GraphQL backend**, not in the article HTML. You cannot `WebFetch` or `curl` the article page to get comments. This skill reverse-engineers that backend so you can pull the raw comments as JSON and parse them.

## When to Use
- User asks to read / parse / analyze / summarize the **comments** on any Detik-network article.
- User pastes a `detik.com`, `cnnindonesia.com`, `cnbcindonesia.com` (etc.) URL and wants the discussion.

## How It Works (the key facts)
- The article HTML contains a `CommentComponent({...})` init block with: `idArtikel`, `kanal`, `date`, `title`, `clientId`, `prefix`.
- The comment backend base URL is `https://apicomment.detik.com` (or `https://apicomment.<domain>`).
- It exposes a **GraphQL endpoint**: `https://apicomment.detik.com/graphql` (POST, JSON body).
- The GraphQL `search` query filters by `query: [{name:"news.artikel", terms: <idArtikel>}, {name:"news.site", terms: <prefix>}]`.
  - `<idArtikel>` = numeric article id (e.g. `1353365`).
  - `<prefix>` = the `prefix` value from the init block, e.g. `cnn` for cnnindonesia.com, `dtk` for detik.com, `cnbc` for cnbcindonesia.com.
- `counter` in the response = total comment count. `hits.results` = top-level comments; each may have a `child` array (replies, which can nest further `child`).

## Quick Start
1. From the article URL or HTML, get `idArtikel` and `prefix`.
   - Easiest: `grep -o -E "idArtikel\s*:\s*[0-9]+" page.html` and `grep -o -E "prefix\s*:\s*'[a-z]+'" page.html`.
2. Run the bundled script:
   ```
   python3 scripts/fetch_comments.py --id <idArtikel> --site <prefix> [--sort newest|like|reply] [--size 50]
   ```
   It prints total count, fetches all pages, and writes `comments_raw.json` in the cwd.
3. Parse `comments_raw.json` (each item: `author` {name,uniqueid}, `content`, `like`, `dislike`, `create_date` unix ts, `child`[]).

## Gotchas
- `author`, `liker`, `disliker`, `reporter` are OBJECT/List types — they **must** have sub-selections in the GraphQL query, or you get a 400. Use: `author`, `liker { name uniqueid }`, `disliker { name uniqueid }`, `reporter { id status_report }`. (Note: `author` returns a JSON object, so just select `author` — do NOT add `{...}` under it. The provided script already does this correctly.)
- Send `Origin: https://<the-article-domain>` and a `User-Agent` header, or you may get 405/403. The script uses `curl` via subprocess + a cookie jar, which works reliably.
- `create_date` is a **Unix timestamp** (float seconds). Convert to WIB with `+7h`.
- A 405 from Python `urllib` is normal — use `curl`/subprocess instead (the script does this).
- Comment counts are small and the section is moderated; do not treat them as a full民意 sample.

## Output
Deliver to the user as a translated/parsed write-up (Indonesian → target language), grouping by stance (support / satire / constructive-criticism / opposition / emotional). Show like/dislike counts as a proxy for resonance.
