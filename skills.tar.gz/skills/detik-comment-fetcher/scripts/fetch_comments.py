#!/usr/bin/env python3
"""Fetch reader comments from a Detik-network article via its GraphQL backend.

Usage:
  python3 fetch_comments.py --id 1353365 --site cnn
  python3 fetch_comments.py --id 1353365 --site cnn --sort like --size 50

Writes comments_raw.json (top-level comments + nested child replies) to cwd.
"""
import json
import subprocess
import sys
import argparse

URL = "https://apicomment.detik.com/graphql"

QUERY = """
query search($type: String!, $size: Int!, $sort: String!, $page: Int!, $query: [ElasticSearchAggregation]) {
  search(type: $type, size: $size, sort: $sort, page: $page, query: $query) {
    counter
    counterparent
    paging
    profile
    hits {
      results {
        id
        author
        content
        like
        dislike
        prokontra
        status
        moderation_level
        news
        create_date
        pilihanredaksi
        pin
        pin_date
        refer
        liker { name uniqueid }
        disliker { name uniqueid }
        reporter { id status_report }
        child {
          id
          child
          parent
          author
          content
          like
          dislike
          prokontra
          status
          moderation_level
          create_date
          pilihanredaksi
          pin
          pin_date
          refer
          liker { name uniqueid }
          disliker { name uniqueid }
          reporter { id status_report }
        }
      }
    }
  }
}
"""


def fetch(page, art_id, site, size=50, sort="newest"):
    vars = {
        "type": "comment",
        "size": size,
        "sort": sort,
        "page": page,
        "query": [
            {"name": "news.artikel", "terms": art_id},
            {"name": "news.site", "terms": site},
        ],
    }
    body = json.dumps({"query": QUERY, "variables": vars})
    out = subprocess.run(
        ["curl", "-s", "-X", "POST", URL,
         "-H", "Content-Type: application/json",
         "-H", "Accept: application/json",
         "-H", "User-Agent: Mozilla/5.0",
         "-H", "Origin: https://www.cnnindonesia.com",
         "--data", body],
        capture_output=True, text=True,
    )
    try:
        return json.loads(out.stdout)
    except Exception:
        print("PARSE ERR page", page, ":", out.stdout[:500])
        raise


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--id", type=int, required=True, help="article id (idArtikel)")
    ap.add_argument("--site", default="cnn", help="site prefix, e.g. cnn / dtk / cnbc")
    ap.add_argument("--sort", default="newest", help="newest | like | reply")
    ap.add_argument("--size", type=int, default=50)
    args = ap.parse_args()

    all_results = []
    page = 1
    total = None
    while True:
        data = fetch(page, args.id, args.site, args.size, args.sort)
        if "errors" in data:
            print("GRAPHQL ERR:", data["errors"])
            break
        s = data["data"]["search"]
        if total is None:
            total = s.get("counter")
            print("TOTAL COMMENTS:", total)
        results = s["hits"]["results"]
        print(f"page {page}: got {len(results)}")
        all_results.extend(results)
        if len(results) < args.size:
            break
        page += 1
        if total and len(all_results) >= total:
            break

    with open("comments_raw.json", "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print("SAVED", len(all_results), "top-level comments to comments_raw.json")


if __name__ == "__main__":
    main()
