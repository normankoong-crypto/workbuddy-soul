# Chart Cheatsheet

Minimal working code for each chart type. Copy the relevant section, adapt data + sheet names, ship.

## Stacked Column

```python
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference

wb = Workbook()
ws = wb.active

# Data: years as categories, segments as series
ws.append(["Year", "Segment A", "Segment B", "Segment C"])
ws.append([2023, 100, 200, 700])
ws.append([2024, 120, 180, 650])
ws.append([2025, 150, 160, 500])

chart = BarChart()
chart.type = "col"
chart.style = 10
chart.grouping = "stacked"
chart.overlap = 100  # required for true stacked
chart.title = "Stacked Column Example"
chart.y_axis.title = "Sales"
chart.x_axis.title = "Year"
chart.x_axis.delete = False
chart.y_axis.delete = False
chart.height = 12
chart.width = 20

# Categories: column A, rows 2-4
cats = Reference(ws, min_col=1, min_row=2, max_row=4)
# Data: columns B-D, rows 1-4 (include header for series titles)
data = Reference(ws, min_col=2, max_col=4, min_row=1, max_row=4)

chart.add_data(data, titles_from_data=True)
chart.set_categories(cats)
ws.add_chart(chart, "F2")

wb.save("stacked_column.xlsx")
```

## 100% Stacked Column

Same as above but `chart.grouping = "percentStacked"`. Shows proportion instead of absolute values.

## Pie Chart

```python
from openpyxl import Workbook
from openpyxl.chart import PieChart, Reference

wb = Workbook()
ws = wb.active
ws.append(["Category", "Value"])
ws.append(["A", 30])
ws.append(["B", 50])
ws.append(["C", 20])

chart = PieChart()
chart.title = "Pie Example"
chart.height = 12
chart.width = 16

labels = Reference(ws, min_col=1, min_row=2, max_row=4)
data = Reference(ws, min_col=2, min_row=1, max_row=4)  # include header
chart.add_data(data, titles_from_data=True)
chart.set_categories(labels)

# Per-slice colors
from openpyxl.chart.series import DataPoint
from openpyxl.chart.shapes import GraphicalProperties
ser = chart.series[0]
colors = ["FF0000", "00FF00", "0000FF"]
for i, color in enumerate(colors):
    pt = DataPoint(idx=i)
    pt.graphicalProperties = GraphicalProperties(solidFill=color)
    ser.dPt.append(pt)

ws.add_chart(chart, "D2")
wb.save("pie.xlsx")
```

## Line Chart

```python
from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference

wb = Workbook()
ws = wb.active
ws.append(["Month", "Product A", "Product B"])
for i, (a, b) in enumerate([(10, 20), (15, 18), (12, 25)], start=2):
    ws.cell(row=i, column=1, value=f"M{i-1}")
    ws.cell(row=i, column=2, value=a)
    ws.cell(row=i, column=3, value=b)

chart = LineChart()
chart.title = "Sales Trend"
chart.x_axis.delete = False
chart.y_axis.delete = False
chart.height = 10
chart.width = 20

data = Reference(ws, min_col=2, max_col=3, min_row=1, max_row=4)
chart.add_data(data, titles_from_data=True)
cats = Reference(ws, min_col=1, min_row=2, max_row=4)
chart.set_categories(cats)
ws.add_chart(chart, "E2")
wb.save("line.xlsx")
```

## Bubble Chart — THE TRICKY ONE

See `openpyxl-gotchas.md` #2 for the full explanation. Short version:

```python
from openpyxl import Workbook
from openpyxl.chart import BubbleChart, Reference
from openpyxl.chart.series_factory import SeriesFactory
from openpyxl.chart.data_source import NumDataSource, NumRef

wb = Workbook()
ws = wb.active
ws.append(["Name", "X", "Y", "Size"])
ws.append(["A", 1, 10, 5])
ws.append(["B", 2, 20, 10])
ws.append(["C", 3, 15, 7])

chart = BubbleChart()
chart.title = "Bubble Example"
chart.x_axis.delete = False
chart.y_axis.delete = False
chart.height = 12
chart.width = 18

x_ref = Reference(ws, min_col=2, min_row=2, max_row=4)
y_ref = Reference(ws, min_col=3, min_row=2, max_row=4)
z_ref = Reference(ws, min_col=4, min_row=2, max_row=4)

ser = SeriesFactory(values=y_ref, xvalues=x_ref, zvalues=z_ref, title="Points")
# Patch yVal and bubbleSize — SeriesFactory sometimes doesn't bind them
if not ser.yVal or not ser.yVal.numRef:
    ser.yVal = NumDataSource(numRef=NumRef(f="Sheet!$C$2:$C$4"))
if not ser.bubbleSize or not ser.bubbleSize.numRef:
    ser.bubbleSize = NumDataSource(numRef=NumRef(f="Sheet!$D$2:$D$4"))

chart.series.append(ser)
ws.add_chart(chart, "F2")
wb.save("bubble.xlsx")
```

**Always validate** that `chart.series[0].yVal.numRef.f` is not None before delivering. See `scripts/validate.py`.

## Scatter Chart

```python
from openpyxl.chart import ScatterChart, Reference, Series

chart = ScatterChart()
chart.title = "Scatter"
chart.style = 13
chart.x_axis.delete = False
chart.y_axis.delete = False

xvalues = Reference(ws, min_col=2, min_row=2, max_row=N)
yvalues = Reference(ws, min_col=3, min_row=2, max_row=N)
series = SeriesFactory(values=yvalues, xvalues=xvalues, title="Series")
chart.series.append(series)
ws.add_chart(chart, "E2")
```

## Bar (horizontal)

```python
chart = BarChart()
chart.type = "bar"  # NOT "col"
chart.grouping = "stacked"
# ... rest same as stacked column
```

## Adding a chart to an existing workbook

```python
from openpyxl import load_workbook
from openpyxl.chart import BarChart, Reference

wb = load_workbook("existing.xlsx")
ws = wb["Sheet1"]

chart = BarChart()
data = Reference(ws, min_col=2, max_col=4, min_row=1, max_row=10)
chart.add_data(data, titles_from_data=True)
cats = Reference(ws, min_col=1, min_row=2, max_row=10)
chart.set_categories(cats)
ws.add_chart(chart, "G2")

wb.save("existing.xlsx")  # overwrites
```
