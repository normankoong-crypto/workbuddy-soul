# openpyxl Gotchas

A list of traps I keep hitting when building Excel files with openpyxl. Each one cost me at least 30 minutes. Read this before you build anything non-trivial.

## 1. Column drift: never use `3 + i*3` to compute column positions

**The bug:**
```python
# Headers in D/E/F (columns 4/5/6)
for i, year in enumerate(years):
    ws.cell(row=4, column=4 + i*3, value="TOTAL")  # ✅ correct
# But data:
for i, year in enumerate(years):
    ws.cell(row=5, column=3 + i*3, value=total)    # ❌ off by one — wrote to C/F/I not D/G/J
```

**The symptom:** total values appear under percentage columns, percentages appear under total columns. You don't notice until the user compares against their source.

**The fix:** pin every column with a named constant. See build_chart.py for the pattern.

## 2. BubbleChart Series: use SeriesFactory, not Series

**The bug:**
```python
from openpyxl.chart.series import Series
series = Series(values=y_ref, xvalues=x_ref, zvalues=z_ref)  # silently broken
# OR
series = Series(xVal=x_ref, yVal=y_ref, bubbleSize=z_ref)     # TypeError
```

**The symptom:** chart renders but is empty / has no Y values. `series.val` is None.

**The fix:**
```python
from openpyxl.chart.series_factory import SeriesFactory
from openpyxl.chart.data_source import NumDataSource, NumRef
series = SeriesFactory(values=y_ref, xvalues=x_ref, zvalues=z_ref)
# SeriesFactory sometimes doesn't bind yVal/bubbleSize — patch manually:
if not series.yVal or not series.yVal.numRef:
    series.yVal = NumDataSource(numRef=NumRef(f=f"'{sheet}'!$B$5:$B$7"))
if not series.bubbleSize or not series.bubbleSize.numRef:
    series.bubbleSize = NumDataSource(numRef=NumRef(f=f"'{sheet}'!$E$5:$E$7"))
```

**Validation:** always check `chart.series[0].yVal.numRef.f` is not None after building.

## 3. `$` in chart references breaks naive `in` checks

**The bug:**
```python
assert "A5" in chart.series[0].xVal.numRef.f
# Fails: chart wrote '$A$5', so the string is "'Sheet'!$A$5:$A$7" — 'A5' is NOT in it
```

**The fix:**
```python
ref = chart.series[0].xVal.numRef.f.replace('$', '')
assert "A5" in ref  # ✅ works
```

## 4. Sheet names in chart refs are wrapped in single quotes

`Reference(ws, ...).numRef.f` produces something like `"'Chart Data'!$A$5:$A$7"`. Note the single quotes around the sheet name. Use `in` (substring check) not `==` (equality check).

## 5. `numCache` is None after save

openpyxl doesn't cache the actual values when saving. Only `numRef.f` (the formula string) is populated. Don't write validation that reads `numCache`.

## 6. Color hex must be 6 chars, not 3

```python
PatternFill("solid", fgColor="FFF")  # ❌ treated as alpha=FF, color="FF" (broken)
PatternFill("solid", fgColor="FFFFFF")  # ✅ correct
```

Same for `GraphicalProperties(solidFill="4472C4")` — 6 chars only.

## 7. To set per-data-point colors, use `DataPoint` from `openpyxl.chart.series`

```python
from openpyxl.chart.series import DataPoint as SeriesDataPoint
pt = SeriesDataPoint(idx=0)
pt.graphicalProperties = GraphicalProperties(solidFill="4472C4")
series.dPt.append(pt)
```

Don't use `from openpyxl.chart.marker import DataPoint` — different class, different API.

## 8. `chart.x_axis.delete = True` is the default — axes will vanish

```python
chart = BubbleChart()
chart.x_axis.delete = False  # keep them
chart.y_axis.delete = False
```

Without this, your chart has no axis labels and the user can't read it.

## 9. `font.color` needs `Color` object, not a string

```python
from openpyxl.styles import Font
cell.font = Font(color="FF0000")  # ❌ broken
from openpyxl.styles.colors import Color
cell.font = Font(color=Color(rgb="FF0000"))  # ✅ correct
```

Actually `Font(color="FF0000")` works in most cases via implicit conversion — but if it doesn't, use the Color wrapper.

## 10. `Workbook` doesn't have a `default_sheet` property

If you're copying code from a 2015 StackOverflow answer, `wb.default_sheet` doesn't exist. Use `wb.active` and `wb.create_sheet()`.

## 11. Loading a saved file doesn't preserve charts in their original form

After `wb.save()` and `wb.load_workbook()`, the chart object's `numRef.f` is intact, but you can no longer mutate chart properties via the `Workbook`'s chart list — it's a copy. If you need to read-then-modify, modify first, then save.

## 12. The 5-second sanity check before delivery

After every build, run this 5-line check before showing the file to the user:

```python
from openpyxl import load_workbook
wb = load_workbook("output.xlsx")
ws = wb["<data sheet>"]
for r in range(1, ws.max_row + 1):
    for c in range(1, ws.max_column + 1):
        v = ws.cell(row=r, column=c).value
        if v is not None:
            print(f"  {chr(64+c)}{r} = {v}")
```

If the printed layout matches what you intended, you're probably fine. If anything is in the wrong place, fix before delivering.
