"""
validate.py — Self-validate a freshly-built .xlsx chart file

Run this AFTER build_chart.py (or any openpyxl chart builder) to catch:
  - Wrong sheet names
  - Headers in wrong columns
  - Data values in wrong cells (column drift bug)
  - Chart series pointing at wrong ranges
  - Missing/None chart references (BubbleChart's biggest footgun)
  - Missing conditional formatting

Usage:
  python validate.py <path-to-xlsx>

Exits 0 on all-pass, non-zero on any FAIL.
"""

import sys
import os
from openpyxl import load_workbook

# ============ Configure your expected values here ============
EXPECTED_SHEETS = ["Chart Data", "Chart"]

# Row 4 headers — must match build_chart.py
EXPECTED_HEADERS = [
    "车型 (Model)", "OTR 价格 (Rp)", "月销量下限",
    "月销量上限", "月销量中位数", "备注"
]

# Expected data rows (model, price, min, max, median)
# Adapt to your file — these are sample values from the demo
EXPECTED_DATA = [
    ("Mitsubishi Triton DC HDX", 473500000, 120, 180, 150),
    ("Mitsubishi Triton DC GLS", 492500000, 250, 350, 300),
    ("Toyota Hilux DC G",       490100000, 150, 250, 200),
]

DATA_FIRST_ROW = 5
DATA_SHEET = "Chart Data"
CHART_SHEET = "Chart"

# Expected chart series data references (after stripping $ for absolute refs)
# Note: sheet names in refs are wrapped in single quotes like 'Sheet'!A1
DATA_REF = f"'{DATA_SHEET}'"
EXPECTED_X = f"{DATA_REF}!A{DATA_FIRST_ROW}:A{DATA_FIRST_ROW + len(EXPECTED_DATA) - 1}"
EXPECTED_Y = f"{DATA_REF}!B{DATA_FIRST_ROW}:B{DATA_FIRST_ROW + len(EXPECTED_DATA) - 1}"
EXPECTED_Z = f"{DATA_REF}!E{DATA_FIRST_ROW}:E{DATA_FIRST_ROW + len(EXPECTED_DATA) - 1}"


def check(label, condition, detail=""):
    """Print ✅ or ❌ and return True/False."""
    icon = "✅" if condition else "❌"
    msg = f"{icon} {label}"
    if detail:
        msg += f" — {detail}"
    print(msg)
    return condition


def main(path):
    if not os.path.exists(path):
        print(f"❌ File not found: {path}")
        return 1

    print(f"=== Validating: {path} ===\n")
    all_ok = True

    wb = load_workbook(path)

    # === Check 1: Sheet names ===
    if not check("Sheet names", wb.sheetnames == EXPECTED_SHEETS,
                 f"got {wb.sheetnames}"):
        all_ok = False

    # === Check 2: Headers in row 4 ===
    ws = wb[DATA_SHEET]
    actual_headers = [ws.cell(row=4, column=c).value for c in range(1, len(EXPECTED_HEADERS) + 1)]
    if not check("Headers in row 4", actual_headers == EXPECTED_HEADERS,
                 f"got {actual_headers}"):
        all_ok = False

    # === Check 3: Data rows at correct positions ===
    for i, (model, price, mn, mx, med) in enumerate(EXPECTED_DATA):
        r = DATA_FIRST_ROW + i
        actual_model = ws.cell(row=r, column=1).value
        actual_price = ws.cell(row=r, column=2).value
        actual_min   = ws.cell(row=r, column=3).value
        actual_max   = ws.cell(row=r, column=4).value
        actual_med   = ws.cell(row=r, column=5).value
        if not check(f"Row {r} ({model})",
                     (actual_model == model and actual_price == price and
                      actual_min == mn and actual_max == mx and actual_med == med),
                     f"got model={actual_model}, price={actual_price}, "
                     f"min={actual_min}, max={actual_max}, median={actual_med}"):
            all_ok = False

    # === Check 4: Chart exists and has 1 series ===
    ws_ch = wb[CHART_SHEET]
    n_charts = len(ws_ch._charts)
    if not check("Exactly 1 chart on Chart sheet", n_charts == 1,
                 f"found {n_charts}"):
        all_ok = False
    if n_charts >= 1:
        chart = ws_ch._charts[0]
        if not check("Chart has at least 1 series", len(chart.series) >= 1,
                     f"got {len(chart.series)}"):
            all_ok = False

        # === Check 5: Series references (the footgun detector) ===
        ser = chart.series[0]
        x_ref = ser.xVal.numRef.f.replace('$', '') if ser.xVal and ser.xVal.numRef else None
        y_ref = ser.yVal.numRef.f.replace('$', '') if ser.yVal and ser.yVal.numRef else None
        z_ref = ser.zVal.numRef.f.replace('$', '') if ser.zVal and ser.zVal.numRef else None
        # BarChart: x is categories, y is val
        if hasattr(ser, 'cat') and ser.cat and ser.cat.strRef:
            x_ref = ser.cat.strRef.f.replace('$', '')

        if not check("X reference points at expected range",
                     x_ref and EXPECTED_X.replace('$', '') in x_ref,
                     f"expected {EXPECTED_X}, got {x_ref}"):
            all_ok = False
        if not check("Y reference points at expected range",
                     y_ref and EXPECTED_Y.replace('$', '') in y_ref,
                     f"expected {EXPECTED_Y}, got {y_ref}"):
            all_ok = False
        if not check("Z reference (bubble size) NOT None",
                     z_ref is not None and len(z_ref) > 0,
                     f"expected {EXPECTED_Z}, got {z_ref}"):
            all_ok = False

        # === Check 6: Axes are visible ===
        if not check("X axis visible", not chart.x_axis.delete):
            all_ok = False
        if not check("Y axis visible", not chart.y_axis.delete):
            all_ok = False

    print()
    if all_ok:
        print("🎉 All checks passed — file is ready to deliver")
        return 0
    else:
        print("❌ Some checks failed — fix and re-validate")
        return 1


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python validate.py <path-to-xlsx>")
        sys.exit(1)
    sys.exit(main(sys.argv[1]))
