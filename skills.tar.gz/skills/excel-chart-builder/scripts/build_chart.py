"""
build_chart.py — openpyxl Excel chart builder template

Copy this file, replace the `data` and `style` sections, change the chart class
to match the shape you need, and ship.

Demonstrates:
  - Pinning columns with COL_xxx constants (avoid column drift bug)
  - Self-validating after build (catch silent failures)
  - BubbleChart Series binding (the biggest openpyxl footgun)

Validation: run scripts/validate.py after this script completes.
"""

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, PieChart, LineChart, BubbleChart, Reference
from openpyxl.chart.series_factory import SeriesFactory
from openpyxl.chart.data_source import NumDataSource, NumRef
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.chart.series import DataPoint as SeriesDataPoint
from openpyxl.chart.label import DataLabelList

# ============ 1. Pin column positions (NEVER use 3 + i*3) ============
COL_MODEL   = 1   # A
COL_PRICE   = 2   # B
COL_MIN     = 3   # C
COL_MAX     = 4   # D
COL_MEDIAN  = 5   # E
COL_NOTE    = 6   # F

# ============ 2. Define your data ============
data = [
    {"model": "Mitsubishi Triton DC HDX", "price": 473_500_000, "min": 120, "max": 180, "median": 150, "note": "Source: oto.com"},
    {"model": "Mitsubishi Triton DC GLS", "price": 492_500_000, "min": 250, "max": 350, "median": 300, "note": "Source: oto.com"},
    {"model": "Toyota Hilux DC G",       "price": 490_100_000, "min": 150, "max": 250, "median": 200, "note": "Source: zigwheels.co.id"},
]

# ============ 3. Build the data sheet ============
wb = Workbook()
ws = wb.active
ws.title = "Chart Data"

# Title
ws.cell(row=1, column=1, value="Sample Chart Data — replace with your title").font = Font(bold=True, size=14)
ws.cell(row=2, column=1, value="X=车型 | Y=价格 | Bubble=销量").font = Font(italic=True, color="808080")

# Headers (row 4) — use COL_xxx constants
headers = ["车型 (Model)", "OTR 价格 (Rp)", "月销量下限", "月销量上限", "月销量中位数", "备注"]
for i, h in enumerate(headers, start=1):
    cell = ws.cell(row=4, column=i, value=h)
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor="305496")
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = Border(left=Side(style="thin"), right=Side(style="thin"),
                         top=Side(style="thin"), bottom=Side(style="thin"))

# Data rows (row 5+) — use COL_xxx constants
for idx, row in enumerate(data):
    r = 5 + idx
    ws.cell(row=r, column=COL_MODEL,  value=row["model"])
    ws.cell(row=r, column=COL_PRICE,  value=row["price"])
    ws.cell(row=r, column=COL_MIN,    value=row["min"])
    ws.cell(row=r, column=COL_MAX,    value=row["max"])
    ws.cell(row=r, column=COL_MEDIAN, value=row["median"])
    ws.cell(row=r, column=COL_NOTE,   value=row["note"])
    ws.cell(row=r, column=COL_PRICE).number_format = '#,##0'
    for c in range(1, 7):
        ws.cell(row=r, column=c).border = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"), bottom=Side(style="thin")
        )

# Column widths
for col, width in [('A', 32), ('B', 18), ('C', 12), ('D', 12), ('E', 18), ('F', 50)]:
    ws.column_dimensions[col].width = width

# ============ 4. Build the chart sheet ============
ws_ch = wb.create_sheet("Chart")

# === CHOOSE YOUR CHART CLASS ===
# For stacked column: chart = BarChart(); chart.type = "col"; chart.grouping = "stacked"
# For pie:            chart = PieChart()
# For bubble:         chart = BubbleChart() (see special Series binding below)
chart = BubbleChart()
chart.style = 18
chart.title = "Sample Bubble Chart"
chart.x_axis.title = "车型"
chart.y_axis.title = "OTR 价格 (Rp 100M)"
chart.x_axis.delete = False  # keep axes visible
chart.y_axis.delete = False
chart.height = 14
chart.width = 24

# Build references — these are cell ranges like 'Chart Data'!$A$5:$A$7
n_data = len(data)
first = 5
last  = 5 + n_data - 1
sheet = "Chart Data"

x_ref = Reference(ws, min_col=COL_MODEL,  min_row=first, max_row=last)
y_ref = Reference(ws, min_col=COL_PRICE,  min_row=first, max_row=last)
z_ref = Reference(ws, min_col=COL_MEDIAN, min_row=first, max_row=last)

# For BarChart/PieChart/LineChart:
#   series = SeriesFactory(values=y_ref, title="...")
#   chart.series.append(series)

# For BubbleChart — special binding (the openpyxl footgun):
series = SeriesFactory(values=y_ref, xvalues=x_ref, zvalues=z_ref, title="Series 1")
if not series.yVal or not series.yVal.numRef:
    series.yVal = NumDataSource(numRef=NumRef(f=f"'{sheet}'!$B${first}:$B${last}"))
if not series.bubbleSize or not series.bubbleSize.numRef:
    series.bubbleSize = NumDataSource(numRef=NumRef(f=f"'{sheet}'!$E${first}:$E${last}"))

# Per-data-point colors (optional, makes bubbles distinguishable)
colors = ["4472C4", "70AD47", "ED7D31"]
for i, color in enumerate(colors[:n_data]):
    pt = SeriesDataPoint(idx=i)
    pt.graphicalProperties = GraphicalProperties(solidFill=color)
    series.dPt.append(pt)

# Data labels
series.dLbls = DataLabelList(showVal=True)

chart.series.append(series)
ws_ch.add_chart(chart, "B2")

# ============ 5. Save and validate ============
out = "chart_output.xlsx"
wb.save(out)
print(f"✅ Saved: {out}")
print(f"   Sheets: {wb.sheetnames}")
print()
print("Next: run scripts/validate.py to catch any silent failures")
