---
name: excel-chart-builder
description: Generate Excel files with charts (stacked column, pie, bubble, bar) using openpyxl. This skill should be used when the user asks to build a chart, table, or .xlsx file from data they have — especially when the chart needs to be copy-pasted into PowerPoint. Includes a self-validation pattern that catches the common "column misalignment" bug before delivery.
agent_created: true
---

# Excel Chart Builder

Build `.xlsx` files with tables + charts using openpyxl, with **mandatory self-validation** before delivery. The pattern was developed to solve a recurring problem: charts silently end up empty, misaligned, or referencing wrong cells when the code "looks right" but is subtly broken.

## When to Use This Skill

Use when the user asks to:
- Build an Excel table with a chart (stacked column, pie, bubble, bar, line, area)
- Recreate an existing chart from a screenshot
- Generate a `.xlsx` that will be copy-pasted into PowerPoint
- Fix a previous chart that "looks wrong" (numbers in wrong columns, chart empty, etc.)

Do NOT use when:
- User just wants raw CSV (use a simple text format)
- User is editing an existing .xlsx in place (use Edit tool on cells)
- The chart is a one-off doodle that doesn't need to be reusable

## Quick Start

Copy `scripts/build_chart.py` and adapt:
1. Define data + style
2. Build workbook with explicit `COL_xxx` column constants
3. Render chart
4. **Run `scripts/validate.py` before claiming done**

## Core Principles

### 1. Pin columns with constants, never compute them

```python
# ✅ CORRECT — columns are named, not computed
COL_MODEL    = 1   # A
COL_PRICE    = 2   # B
COL_MIN      = 3   # C
COL_MAX      = 4   # D
COL_MEDIAN   = 5   # E
ws.cell(row=5, column=COL_PRICE, value=price)

# ❌ WRONG — easy to off-by-one, easy to break on refactor
ws.cell(row=5, column=3 + i*3, value=price)  # silent column drift
```

**Why this matters:** A real bug from this project: code wrote headers to D/E/F but data to C/D/E, producing a column-shifted table that "looked fine" until the user compared it against the source. Validation passed because each cell had SOME value.

### 2. Match the chart class to the data shape

| Chart type | openpyxl class | Series params | Data binding |
|---|---|---|---|
| Pie / Doughnut | `PieChart` / `DoughnutChart` | standard `Series` | `values=` only |
| Bar / Column / Stacked column | `BarChart` | standard `Series` | `categories=` + `values=` |
| Line | `LineChart` | standard `Series` | `categories=` + `values=` |
| **Bubble** | `BubbleChart` | **`SeriesFactory` + manual `yVal/bubbleSize`** | `xVal / yVal / bubbleSize` (NOT `values/xvalues/zvalues`) |
| Scatter | `ScatterChart` | `SeriesFactory` | `xVal / yVal` |

**The BubbleChart trap** (this is the biggest footgun in openpyxl):
```python
# ❌ WRONG — Series() doesn't accept xVal/yVal/bubbleSize as kwargs
series = Series(xVal=x_ref, yVal=y_ref, bubbleSize=z_ref)  # TypeError
series = Series(values=y, xvalues=x, zvalues=z)            # silently broken — Y data lost

# ✅ CORRECT — use SeriesFactory, then manually bind
from openpyxl.chart.series_factory import SeriesFactory
from openpyxl.chart.data_source import NumDataSource, NumRef
series = SeriesFactory(values=y_ref, xvalues=x_ref, zvalues=z_ref)
if not series.yVal or not series.yVal.numRef:
    series.yVal = NumDataSource(numRef=NumRef(f=f"'{sheet}'!$B$5:$B$7"))
if not series.bubbleSize or not series.bubbleSize.numRef:
    series.bubbleSize = NumDataSource(numRef=NumRef(f=f"'{sheet}'!$E$5:$E$7"))
```

**Validation:** after building, dump `chart.series[0].yVal.numRef.f` — it must NOT be None. If it is, the chart will render empty.

### 3. Always self-validate before claiming done

`scripts/validate.py` checks:
- Sheet names match expected
- Headers in row 4 match expected list
- Data rows have correct values at correct cells
- Chart series data references point at the expected ranges
- Conditional formatting / fills applied where expected

**Common validation pitfalls:**
- `assert 'A5' in chart_ref` fails because openpyxl writes `$A$5` (absolute reference) → use `chart_ref.replace('$', '')` first
- Sheet names in chart refs are wrapped in single quotes: `'Sheet'!$A$1` → check with `in`, not equality
- `numCache` is None after save (openpyxl doesn't cache values) — only check `numRef.f` (the formula string)

## Standard File Layout

For a "table + chart" deliverable, use this structure:

```
Sheet 1: <ChartName> Data
  Row 1: Title (bold, size 14)
  Row 2: Subtitle (italic, gray)
  Row 4: Headers (bold white on dark blue, with borders)
  Row 5..N: Data (alternating fill, right-align numbers, left-align text)

Sheet 2: <ChartName> Chart
  Anchor chart at B2, height=14, width=24
  Set chart.x_axis.delete = False and chart.y_axis.delete = False (or axes vanish)

Sheet 3: Data Sources & Notes
  Table of (field, source URL or note)
  First row is header, styled same as Sheet 1

Sheet 4: Key Findings (optional)
  Numbered list of insights, wrap_text=True, row height 32
```

## Workflow

1. **Get data from user** — accept pasted tables, screenshots, or dict/list
2. **Build the data sheet first** — chart references will point at this; getting the table right is the hardest part
3. **Pin columns with `COL_xxx` constants** before writing any cell
4. **Build the chart sheet** with the correct chart class for the shape
5. **Run `scripts/validate.py`** — fix any FAIL before presenting to user
6. **If validation fails**: read the actual file with `load_workbook`, dump the cells, find the mismatch, fix, re-run
7. **Present the file** with `present_files` and a short summary of what was built

## Resources

### scripts/build_chart.py
Boilerplate template. Copy, replace `data` and `style` sections, change chart class, ship.

### scripts/validate.py
Standalone validation script. Run after building to catch: wrong sheet names, wrong headers, wrong column positions, wrong chart refs, missing conditional formatting. Prints `✅` for each check, exits non-zero on any FAIL.

### references/openpyxl-gotchas.md
Detailed list of openpyxl traps encountered in real projects: column drift, $ in refs, BubbleChart Series binding, numCache being None, sheet name quoting, color hex format (must be 6 hex chars not 3), etc.

### references/chart-cheatsheet.md
Minimal working code for: stacked column, 100% stacked, pie, doughnut, line, scatter, bubble, bar. Copy-paste starter for each.
