# Project Memory

## Norman's Mac Setup
- macOS 26.0.1 (Tahoe), Unix username: yangbinyi, display name: Jinghua
- Terminal prompt customized: ~/.zshrc with `PROMPT='Jinghua@%m %% '`
- LocalHostName changed from MacBook-Pro-3 to MacBook-Pro
- ComputerName: MacBook Pro
- Norman prefers display name "Jinghua" on terminal

## Norman's Preferences
- **必须解释原理**：Norman 要求每个操作都配上简单易懂的原理解释，不能只给步骤。他不想被"架空"，想真正理解自己在做什么。用大白话+类比的方式解释。
- 喜欢用类比理解技术概念
- 吉利电动皮卡国际销售（印尼/马来市场）
- BOM/选配固定化策略是业务讨论中的常见话题（缅甸项目已有先例）
